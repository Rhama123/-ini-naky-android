# INI NAKY Voice Community — Proyek APK WebView

Proyek Android native sederhana untuk membuka website:
`https://6aefbd690a46b.site123.me/`

## Build APK melalui GitHub Actions (tanpa Termux)

1. Ekstrak ZIP ini.
2. Buat repository GitHub baru, misalnya `ini-naky-android`.
3. Unggah seluruh isi folder proyek ke repository (bukan folder ZIP-nya).
4. Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
5. Buka tab **Actions** pada repository.
6. Pilih workflow **Build INI NAKY APK** lalu tekan **Run workflow** (atau tunggu build otomatis setelah push ke `main`).
7. Setelah proses selesai, buka hasil workflow yang berstatus hijau.
8. Di bagian **Artifacts**, unduh `INI-NAKY-APK`.
9. Ekstrak file ZIP artifact dan pasang `app-debug.apk` di HP Android.

## Catatan penting

- APK ini adalah pembungkus website, bukan aplikasi Hapi lengkap.
- Login, room suara, koin, hadiah, dan VIP hanya berfungsi jika fitur tersebut memang sudah tersedia dan terhubung pada website/backend.
- Akses mikrofon dari halaman web memerlukan HTTPS, izin Android, permintaan izin WebView, serta dukungan WebRTC pada halaman/layanan voice chat.
- Implementasi ini menangani izin audio. Izin kamera dideklarasikan, tetapi akses kamera tidak otomatis diaktifkan.
- Gunakan APK debug untuk pengujian. Untuk distribusi publik, buat APK release yang ditandatangani dengan keystore yang disimpan aman.
- Jangan membagikan file keystore atau kata sandinya.
- Jika build gagal, buka log workflow dan kirimkan pesan error terakhir untuk diperbaiki.

## Spesifikasi

- App name: INI NAKY
- Application ID: com.ininaky.voicecommunity
- Version: 1.0.0
- Min SDK: 23
- Target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
